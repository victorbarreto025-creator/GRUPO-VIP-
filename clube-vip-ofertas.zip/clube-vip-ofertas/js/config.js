// ============ CONFIGURAÇÃO CENTRALIZADA ============
// Edite só este arquivo para trocar links, IDs, vídeo e imagens. Não coloque senhas, tokens ou chaves privadas aqui
// (este arquivo é público). IDs de pixel são públicos por natureza.
const CONFIG = {
  checkoutUrl: "",                       // link de pagamento Zuptos (vazio = botões rolam até a oferta)
  demoVideo: { url: "", poster: "", ratio: "16/9",   // ex.: "assets/videos/demonstracao-grupo.mp4" ou link do YouTube
    title: "Veja tudo funcionando na prática.",
    subtitle: "Conheça o grupo VIP e veja como utilizar as ofertas na sua própria divulgação." },
  results: {
    title: "Resultados reais de quem já divulga ofertas.",
    value: "R$ 670,70", text: "Em vendas geradas na Shopee em 30 dias.",
    period: "21/09/2026 a 20/10/2026",
    images: [],                          // ex.: [{ src: "assets/images/resultado-shopee.webp", alt: "Painel de afiliados Shopee" }]
    caption: "Print original do painel de afiliados da Shopee.",
    disclaimer: "Resultados pessoais. Não há garantia de resultados semelhantes." },
  products: [                            // miniaturas da busca "Air Fryer" (vazio = ilustração embutida)
    { image: "" },                       // ex.: "assets/images/produto-airfryer-1.webp"
    { image: "" }, { image: "" }],
  tracking: {                            // só carrega o que tiver ID preenchido
    metaPixelId: "",                     // ID do Meta Pixel
    utmifyPixelId: "",                   // ID do pixel da UTMify
    utmifyUtms: false,                   // true = carrega o script de UTMs da UTMify
    extraScripts: []                     // URLs de outros scripts oficiais (https://...)
  },
  contact: { supportUrl: "", termsUrl: "", privacyUrl: "", refundUrl: "" }  // ex.: "mailto:suporte@seudominio.com" ou "termos.html"
};
